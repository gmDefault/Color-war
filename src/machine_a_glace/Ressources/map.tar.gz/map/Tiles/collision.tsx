<?xml version="1.0" encoding="UTF-8"?>
<tileset name="collision" tilewidth="32" tileheight="32" tilecount="25">
 <image source="collision.png" width="160" height="160"/>
</tileset>
