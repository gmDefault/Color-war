<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset" tilewidth="32" tileheight="32" tilecount="4096">
 <image source="../../../../../../../Téléchargements/32x32.png" width="4096" height="1024"/>
</tileset>
